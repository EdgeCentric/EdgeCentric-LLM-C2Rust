#if 1
void f(some_t s, int b)
#else
void f(some_t s)
#endif
{
}
