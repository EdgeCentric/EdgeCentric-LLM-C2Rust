#!/bin/sh
clang -fsyntax-only example2.c 
clang -fsyntax-only example1.c 
clang -fsyntax-only example4.c 
clang -fsyntax-only test.c 
clang -fsyntax-only example3.c 
clang -fsyntax-only genann.c 
