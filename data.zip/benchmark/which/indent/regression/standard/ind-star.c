main ()
{
  int code;

  /*
   *  Thang.
   */
  code = 1;
}
