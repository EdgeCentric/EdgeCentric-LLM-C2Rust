void foo()
{
#ifdef foo
    if (1) {
    }				/* if */
#endif
}
