
static int func(int i, int j) {
    int i;
    i = 10;
    if (i == 6) 
    {
        i++;
    }
    else
    {
        i--;
    }
}

struct xyz
{
    int i;
    int j;
} iii;

typdef struct 
{
    int i;
    int j;
} iii_st;

