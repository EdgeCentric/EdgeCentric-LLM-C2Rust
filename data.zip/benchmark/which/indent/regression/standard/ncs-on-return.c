unsigned char *cp = (unsigned char *)ptr;
int
foo ()
{
  return (int)n;
}
