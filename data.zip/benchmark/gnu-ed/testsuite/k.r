This natural inequality of the two powers of population and of
All other arguments are of slight and subordinate consideration in
comparison of this. I see no way by which man can escape from the weight
hello world
of this law which pervades all animated nature. No fancied equality, no
agrarian regulations in their utmost extent, could remove the pressure
