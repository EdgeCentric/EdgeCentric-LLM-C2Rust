#if x
#if y
# if z
#define www
#else
# define ggg
#endif
#else
#  define kkk
#endif
#endif
