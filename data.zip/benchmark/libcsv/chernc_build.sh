#!/bin/sh
./configure
make clean
make

