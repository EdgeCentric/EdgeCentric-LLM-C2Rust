b (struct z *a)
{
}
