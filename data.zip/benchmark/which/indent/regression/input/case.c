int foo(void)
{
  if (0) {
    switch (x)
    {
      case 1:
	++x;
	break;
      case 1:
      {
	++x;
	break;
      }
    }
  }
}
