void
zero (void)
{
  struct cmtsConfig cmtscfg;	/* CMTS configuration table used for
				   initialization */
}
