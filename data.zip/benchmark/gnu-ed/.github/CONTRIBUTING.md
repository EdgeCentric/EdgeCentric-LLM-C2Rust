# Contributing to this repository

This repository is a mirror of [GNU ed](https://www.gnu.org/software/ed/). In order to contribute to the actual software, email the GNU ed mailing list at [bug-ed@gnu.org](mailto:bug-ed@gnu.org).

This repository should only contain official stable releases of GNU ed. Please ensure that all files are updated, and any files deleted in the new version (particularly test files) are removed from the tree.
