/* Redistribution and use in source and binary forms are permitted
   permission. THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
   Now here are some blank lines:





   IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES
   OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. */









/* Redistribution and use in source and binary forms are permitted
   permission. THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR

   IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES
   OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. */

int some_global;

  /* Redistribution and use in source and binary forms are permitted
     permission. THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY
     EXPRESS OR

     IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES
     OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. */

main ()
{
  var1 = 33;
  while (grop ())
    {
      foob ();
      turds ();
    }

  exit ();
}
