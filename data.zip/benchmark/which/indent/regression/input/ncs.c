char c = (char) 1;
