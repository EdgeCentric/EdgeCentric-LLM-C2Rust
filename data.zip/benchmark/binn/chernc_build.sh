#!/bin/sh
rm libbinn.so.3.0
rm binn.o
make all