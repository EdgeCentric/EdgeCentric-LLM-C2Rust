int foo = 0b1;
long int foo = 0b1L;
unsigned int foo = 0b1U;
unsigned long int foo = 0b1LU;

int foo = 0B1;
long int foo = 0B1L;
unsigned int foo = 0B1U;
unsigned long int foo = 0B1LU;

int foo = 0b01010101;
int foo = 0B01010101;
