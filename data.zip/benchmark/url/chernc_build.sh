#!/bin/sh
clang -fsyntax-only test.c 
clang -fsyntax-only url.c 
