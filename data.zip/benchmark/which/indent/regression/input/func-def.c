void
  a (int x, int y,
     int z);
void
  b (int x, int y, int z);
