lw5100_add_to_field_list(object, node, row)
GCH_Object *object;
CMM_NODE *node;
int row;
{
	Node_data *data;

/* a000345 */
/*    strcpy_fill(field_name_string, data->name,
		  ' ', 43, NULL, TRUE); */
}
