int snafuscate (		//
		 char *foo,	/* text to be snafuscated */
		 int bar,	/* snafuscation index.  NOTE: For non-integral
				   snafuscation indices, use fsnafuscate().     */
		 int flags)	/* defined in snafuscate.h                      */
{
}

int snafuscate (		/* */
		 char *foo,	/* text to be snafuscated */
		 int bar,	/* snafuscation index.  NOTE: For non-integral
				   snafuscation indices, use fsnafuscate().     */
		 int flags)	/* defined in snafuscate.h                      */
{
}
