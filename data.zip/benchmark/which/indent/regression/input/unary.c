foo ()
{
  return (int) -1;
}
