float foo = 1.0F;
float foo = 1.0f;
double foo = 1.0;
double foo = 1.0;
long double foo = 1.0L;
long double foo = 1.0l;

_Decimal32 foo = 1.0DF;
_Decimal32 foo = 1.0df;
_Decimal64 foo = 1.0DD;
_Decimal64 foo = 1.0dd;
_Decimal128 foo = 1.0DL;
_Decimal128 foo = 1.0dl;
