#!/bin/sh
clang -fsyntax-only grabc.c 
