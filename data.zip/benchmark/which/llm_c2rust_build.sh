make clean
make