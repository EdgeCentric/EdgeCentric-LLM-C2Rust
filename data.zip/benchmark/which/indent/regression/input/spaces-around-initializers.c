struct x
{
  const char *a;
  int b;
} y[] = {
  {"xxx", 0},
  {NULL, 0}
};

int a[] = {1, 2, 3, 4};
