void
main (int argc, char *argv[])
{
/*lint -save *//* test of comment in column 1 */
  farlj ();
}
