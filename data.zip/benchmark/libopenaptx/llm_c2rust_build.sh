#!/bin/sh
make clean
make