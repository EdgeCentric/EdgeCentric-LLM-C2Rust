/**
 * Test comment
 */
int
a(int b)
{
  if (a == b) {
    /* XXX */
  }

  /**
   * This is a block comment
   * spanning multiple lines
   */
  return b;
}
