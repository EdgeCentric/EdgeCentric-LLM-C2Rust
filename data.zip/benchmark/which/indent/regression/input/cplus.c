// Here is a C plus plus commment in column 1
// Here is a C plus plus commment in column 1
// Here is a C plus plus commment in column 1
// Here is a C plus plus commment in column 1
// Here is a C plus plus commment in column 1
// Here is a C plus plus commment in column 1

int var1;	// Delcaration comment 1
int var1;		// Delcaration comment 1 */

main ()
{
  var1 = 33;
  while (grop ())
    {				                     // A comment to right of code.
      foob ();
      turds ();
    }

  /* A single line comment. */
  exit ();
}

// Here is a very long C plus plus comment Here is a very long C plus plus comment very long C plus plus comment

//
// Test comment
//

     /*
      * Another form of boxed
      * comment which should be left the fuck alone!!!
      *
      */


boof ()
{
  var1 = 99;

  return 0;  // Here is a very long C plus plus comment Here is a very long C plus plus comment
}

#if 0
#else    // cpp cplus comment
#endif

#if 0
#else  /* Regular comment */
#endif /* Yet another */
