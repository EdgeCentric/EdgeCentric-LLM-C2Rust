int
q::s ()
{
  int
    i;
}

