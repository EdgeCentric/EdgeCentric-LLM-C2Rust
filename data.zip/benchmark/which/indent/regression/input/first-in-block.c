main()
{
  int i = 0;

  switch (i)
  {
//
// First line comment
//
    case 1:
      return 1;
  }

  switch (i)
  {
 //
 // First line comment, but not col 1.
 //
    case 1:
      return 1;
  }
}
