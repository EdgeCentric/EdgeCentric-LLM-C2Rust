main ()
{
  while (foo)
    {
      bar (33);
      grop ();
    }
  return -1;
}
