# Fuzz Testing

## Compilation

```
./build.sh
```

## Run

To fuzz the decoder:

```
./fuzz_decoder
```

To fuzz the encoder:

```
./fuzz_encoder
```
