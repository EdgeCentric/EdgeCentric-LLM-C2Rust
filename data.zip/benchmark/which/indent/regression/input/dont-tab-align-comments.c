struct zzz {
	const char *a;
} x[] = {
	{ "0" }, /* xxx */
	{ "999999999999999" }, /* yyy */
	{ "test123" } /* zzz */
};
