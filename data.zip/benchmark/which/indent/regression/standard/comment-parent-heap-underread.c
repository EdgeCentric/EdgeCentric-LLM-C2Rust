void
foo (void)
{
/*a*/ (1);
}
