main ()
{
  do
    {
      bar (33);
      grop ();
    }
  while (1);
  return -1;
}
