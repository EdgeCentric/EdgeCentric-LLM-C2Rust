main ()
{
  int size;

  for (size_ = 32; size_ < n; size_ <<= 1);
}
