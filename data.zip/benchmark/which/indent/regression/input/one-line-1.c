main (){ if (foo) { bar (33); grop (); } return -1; }
