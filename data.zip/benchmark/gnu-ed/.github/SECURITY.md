# GNU ed mirror security policy

This repository is a mirror of GNU ed. Please report all bugs related to the
program, including security bugs, to the GNU ed mailing list at
[bug-ed@gnu.org](mailto:bug-ed@gnu.org).
