int aa(int b)
{
	int a = 1;
	if (a == 1) a = 1;
	if (a == 3) a = 1;
	else a = 2;

	if (x()) y = 1;
	if (z()) goto a;
}
