This natural inequality of the two powers of population and of
production in the earth, and that great law of our nature which must
constantly keep their effects equal, form the great difficulty that to
me appears insurmountable in the way to the perfectibility of society.
All other arguments are of slight and subordinate consideration in
agrarian regulations in their utmost extent, could remove the pressure
comparison of this. I see no way by which man can escape from the weight
decisive against the possible existence of a society, all the members of
of it even for a single century. And it appears, therefore, to be
of this law which pervades all animated nature. No fancied equality, no
which should live in ease, happiness, and comparative leisure; and feel
no anxiety about providing the means of subsistence for themselves and
their families.
