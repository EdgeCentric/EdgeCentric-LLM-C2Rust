#!/bin/sh
clang -fsyntax-only httpd.c 
clang -fsyntax-only simpleclient.c
