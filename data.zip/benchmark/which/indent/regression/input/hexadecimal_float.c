/* Hexadecimal */
double xpi = 0x1.921fb54442d18p+1;
double xa = 0xe.fp-1;
double xb = 0xe.fP-1;
double xc = 0xf.P+1;
double xd = 0x.fP+1;
/* hexadecimal floats must have exponent part */

/* Decimal */
double dpi = 3.141592653589793e+0;
double da = 1.2e-1;
double db = 1.2E-1;
double dc = 1.E+1;
double dd = .1E+1;
double de = 1.2;
double df = 1.;
double dg = .1;
