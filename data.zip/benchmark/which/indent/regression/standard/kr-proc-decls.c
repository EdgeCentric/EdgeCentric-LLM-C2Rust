
int toome();

int metoo();

void *bar();

void *rab();

char *foo()
{
    a++;
}

char eatme()
{
    foo();
}
