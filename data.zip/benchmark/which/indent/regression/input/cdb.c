int foo; /* This is a single line comment */
/* this is a column zero real single line comment */
   /* this is elgible for cdb.  */

