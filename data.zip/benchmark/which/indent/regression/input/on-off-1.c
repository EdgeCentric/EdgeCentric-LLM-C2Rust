/* Testing *INDENT-ON* and *INDENT-OFF* controls comments */

// *INDENT-OFF*
// *INDENT-ON*

main(int argc, char **argv)
{  char *foo;
  puts(foo);
}

/* *INDENT-OFF* */
grunt(int argc,
      char **argv)
{     char *foo;
    puts(foo);
}
/* *INDENT-ON* */

frobp (int argc, char **argv)
{
  char *foo;
  puts(foo);
}

