b(struct z *a){}
