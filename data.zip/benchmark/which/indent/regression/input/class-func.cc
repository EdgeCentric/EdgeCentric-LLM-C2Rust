classname::procname ()
{
  if (a)
    1;
}
