void graph_error(fmt, va_alist)
const char *fmt;
va_dcl
{
}

int
label_width(str, lines)
const char *str;
int *lines;
{
}
