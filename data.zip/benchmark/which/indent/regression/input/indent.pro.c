main()
{
  int i, j;

  i <<= 1;
  j >>= 1;
}
