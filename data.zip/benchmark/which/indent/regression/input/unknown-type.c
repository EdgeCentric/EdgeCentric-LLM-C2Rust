#include <foo.h>

Error_t g (void)
{
  return 0;
}

Error_t
g (void)
{
  return 0;
}
