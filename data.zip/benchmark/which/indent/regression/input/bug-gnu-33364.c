main(){return;malloc(x(int)+2*4);}
