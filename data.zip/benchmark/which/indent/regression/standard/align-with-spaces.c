static void
really_long_function_decl (const char *string_here, int integer_here,
                           unsigned long xxx)
{
	if (errno == ENOMEM) {
		ERROR ("unable to allocate memory for a new xxx "
		       "because %s", strerror (errno));
	}

	if (sbuf_add_str (delete_state, SBUF_TSPACE, 0) ||
	    sbuf_add_snum (states[states_allocated - 1].timestamp,
	                   SBUF_SCOLON)) {
		i++;
	}

	switch (x) {
	case XXX:
		if (1) {
			if (modify_mlist (delta->old_file.path,
			                  delta->new_file.path))
				goto err;
		}
		break;
	}
}
