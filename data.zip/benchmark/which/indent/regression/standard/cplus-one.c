// One line cplus comment, no newline
