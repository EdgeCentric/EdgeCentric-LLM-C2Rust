
/* Optional blanklines */

main (foo)
     int foo;
{
  barf ();

  *foo = eat_me ();

  return 93;

  /* Because */

}

/* there wre */
