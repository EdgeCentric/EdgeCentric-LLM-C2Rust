#include "../../src/binn.h"

char * APIENTRY binn_to_json(void *binn);
