int
foo(int a, int *b, char c)
{
}
